#pragma once

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cstdlib>

#include "common.h" // Typedefs, defines, structures et variables communes
#include "io.h" // Inclus <windows.h>
#include "highscores.h"


class shifumi { // Je vais quand même pas l'appeller "pierrefeuilleciseaux"
public:
	int main();
};
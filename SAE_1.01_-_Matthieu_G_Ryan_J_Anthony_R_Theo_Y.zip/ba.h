#pragma once

#include <iostream>
#include <ios>
#include <stdlib.h>
#include <time.h>
#include <cstdlib>

#include "common.h" // Typedefs, defines, structures et variables communes
#include "io.h" // Inclus <windows.h>


class bapple {
public:
	int main();
};